---
title: "Btw-tarief kapper: 9 of 21 procent? Zo voorkom je tienduizenden euro's aan naheffingen"
slug: "btw-tarief-kapper-9-of-21-procent"
category: "kennisbank"
focus_keyphrase: "btw tarief kapper 9 of 21 procent"
meta_description: "Wanneer geldt 9% en wanneer 21% btw in de salon? Voorkom boekenonderzoeken, naheffingsaanslagen en ontdek hoe je combinatiedeals correct splitst."
author: "Vincent van Munster"
date: "2026-09-09"
---

# Btw-tarief kapper: 9 of 21 procent? Zo voorkom je tienduizenden euro's aan naheffingen

Toen ik in 2014 bewust uit de corporate ratrace stapte om fulltime vader te zijn voor mijn twee kinderen, leerde ik aan de keukentafel een fundamentele les: onduidelijke regels leiden altijd tot ruzie en chaos. Als je niet helder bent over wie wat opruimt, blijft de rommel liggen. In de zakelijke wereld is dat exact hetzelfde. 

In mijn tijd als directeur bij Stichting de Baan — waar ik verantwoordelijk was voor 700 deelnemers, 180 vrijwilligers en strenge subsidie-audits van gemeenten — zag ik wat er gebeurt als de administratieve basis rammelt. Eén foute aanname in je grootboek kan je jaren later keihard inhalen. En in de kappersbranche zie ik getalenteerde vakmensen dagelijks worstelen met een sluipend fiscaal risico: **de scheidslijn tussen het 9% en 21% btw-tarief**.

Veel stylisten denken dat vrijwel alles wat ze in de salon doen onder het lage btw-tarief valt. De Belastingdienst denkt daar echter heel anders over. Een verkeerde aanslag op je kassa kan bij een boekenonderzoek over vijf jaar terug oplopen tot een naheffing van tienduizenden euro's, vermeerderd met heffingsrente en vergrijpboetes tot wel 50% of 100%.

## De wet: arbeid versus levering van goederen

Het verlaagde btw-tarief van 9% voor het kappersbedrijf is geen algemene salonsubsidie; het is een gerichte fiscale maatregel om **arbeidsintensieve diensten** te stimuleren. Dit is vastgelegd in **Tabel I, post b.27 van de Wet op de omzetbelasting 1968**.

De wet trekt een vlijmscherpe grens:

* **Het 9% btw-tarief (Diensten / Arbeidscomponent):** Geldt uitsluitend voor de fysieke kappershandeling aan de klant in de salon. Dit betreft wassen, knippen, snijden, scheren, föhnen, permanenten, stylen en het aanbrengen van haarkleuringen.
* **Het 21% btw-tarief (Goederen / Retail & Overig):** Geldt voor álle fysieke producten die je aan de klant verkoopt en die de salon verlaten. Denk aan shampoos, conditioners, haarmaskers, hittebeschermers, borstels, stylingtools, maar ook aan verhuur van stoelen, cadeaubonnen (mits multifunctioneel) en administratieve servicekosten.

```
[DE HARDE SCHEMA-SPLITSING]
Handeling aan de stoel (Knippen/Kleuren)  ──►  9% BTW (Arbeid Tabel I post b.27)
Product in de tas van de klant (Retail)   ──► 21% BTW (Goederenlevering standaard)
```

## Waar het stelselmatig misgaat: de combi-deal valkuil

De grootste fiscale brandhaard ontstaat bij pakketprijzen en salonarrangementen. Om de gemiddelde klantwaarde te verhogen, bieden salons slimme bundels aan:

> *"Lente-Refresh arrangement: Complete knip- en kleurbehandeling inclusief luxe Color-Lock shampoo voor thuis: nu voor €85."*

Slaat jouw medewerker dit bij het afrekenen aan onder één enkele kassa-knop als *"Lente-Refresh €85 (9% btw)"*? Dan bega je in de ogen van de fiscus een zware overtreding. Je verrekent dan immers 9% btw over een fysiek retailproduct dat wettelijk met 21% belast had moeten worden.

```
Rekenvoorbeeld van het fiscale tekort per transactie:

Foutieve boeking (volledig 9%):
€85,00 inclusief 9% btw  ──►  Afgedragen btw: €7,02  (Omzet netto: €77,98)

Wettelijk verplichte splitsing:
- Behandeling: €60,00 incl. 9% btw  ──► Afgedragen btw: €4,95
- Retailproduct: €25,00 incl. 21% btw ──► Afgedragen btw: €4,34
Totale werkelijke btw-schuld: €9,29 (Omzet netto: €75,71)

Verschil per klant: €2,27 te weinig omzetbelasting afgedragen.
Bij 200 van deze pakketten per maand tikt dit in 5 jaar tijd aan tot een structureel btw-tekort van €27.240.
Tel daar een vergrijpboete van 25% tot 50% plus heffingsrente bij op, en je praat over een vordering van meer dan €40.000.
```

## Hoe zit het met extensions, visagie en stoelhuur?

Niet elke dienst binnen de muren van een salon valt onder het lage kappersregime. Let bijzonder scherp op de volgende posten:

1. **Haarextensions en weaves:** Het inzetten, invlechten en stylen van haarextensions is arbeid en valt onder **9%**. De inkoop en levering van het fysieke haar zelf (de banen of matten) geldt echter als levering van een goed en moet belast worden tegen **21%**. Splits je factuur en kassabon daarom altijd uit in *plaatsingsarbeid* en *materiaal*.
2. **Visagie en make-up:** Brengt een stylist make-up aan voor een bruiloft of feest? Visagie is géén kappersbehandeling in de zin van Tabel I post b.27. Visagie valt onverbiddelijk onder het **21% btw-tarief**, zelfs als dezelfde medewerker vijf minuten ervoor het bruidskapsel tegen 9% heeft opgestoken.
3. **Stoelverhuur aan zzp'ers:** Verhuur je een stoel aan een freelance stylist? Dat is geen kappersdienst, maar de verhuur van bedrijfsruimte inclusief salonfaciliteiten. Dit is in principe vrijgesteld van btw, tenzij er geopteerd is voor belaste verhuur, waarbij **21% btw** in rekening wordt gebracht over de stoelhuur.

| Post / Activiteit | Btw-tarief | Wettelijke Grondslag & Voorwaarde |
| :--- | :--- | :--- |
| Wassen, knippen, föhnen, kleuren | **9%** | Tabel I, post b.27 Wet OB (Kappersdienst) |
| Shampoo, wax, borstel mee naar huis | **21%** | Standaardtarief goederenlevering |
| Haarextensions: inzetten & knippen | **9%** | Zuivere kappersarbeid |
| Haarextensions: het haar zelf | **21%** | Levering van een fysiek product |
| Visagie / Make-up workshop | **21%** | Valt buiten kappersdefinitie |
| Stoelverhuur (belast) | **21%** | Expliciete optie belaste verhuur |

## Hoe voorkom je naheffingen? De audit-proof kassa

Je lost dit niet op door 's avonds met een rekenmachine bonnetjes uit te pluizen. Rust op de vloer ontstaat pas wanneer je technologie het kille rekenwerk laat doen.

* **Dwing regelsplitsing af in je salonsoftware:** Werk nooit met globale verzamelgroepen. Elke bundel moet in je kassasysteem automatisch uit elkaar vallen in een 9%-regel en een 21%-regel. Moderne salontools zoals het Nederlandse **Looppiness** doen dit realtime op transactieniveau.
* **Koppel met branchespecialisten:** Laat je boekhouding controleren door partijen die de salonbranche door en door kennen, zoals **Buro Burmanje**. Zij zien direct of jouw omzetverhouding tussen 9% en 21% afwijkt van het landelijke branchegemiddelde (een rode vlag bij inspecteurs).
* **Nul administratieve overuren:** Wanneer de data direct vanuit de kassa via een API-koppeling naar het grootboek stroomt, bespaar je 10 uur per week aan administratief zwoegen.

Geen angst voor de blauwe envelop, maar een rotsvast fundament. Zodat jij overdag met je handen aan de stoel staat en 's avonds met een gerust hart aan tafel zit.

---

*Vincent van Munster is sociaal ondernemer, AI-innovator en oprichter van WeAreImpact en Kappersassistent. Als voormalig welzijnsdirecteur én vader van twee kinderen bouwt hij aan AI-oplossingen met één doel: kille technologie inzetten om warme handen en kostbare tijd vrij te spelen.*

Zullen we eens koffie drinken? Als ondernemer en vader hoor ik graag waar jouw salonpraktijk vandaag de dag écht vastloopt.
