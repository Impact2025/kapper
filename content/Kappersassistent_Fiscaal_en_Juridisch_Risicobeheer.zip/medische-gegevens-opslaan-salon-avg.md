---
title: "Medische gegevens opslaan in je kapsalon: wat mag wél en wat niet onder de AVG?"
slug: "medische-gegevens-opslaan-salon-avg"
category: "kennisbank"
focus_keyphrase: "medische gegevens opslaan salon avg"
meta_description: "Mag een kapper alopecia, chemokuur of psoriasis opslaan in het CRM? Lees hoe Artikel 9 AVG en de EU AI Act salons verplichten tot strikte dataveiligheid."
author: "Vincent van Munster"
date: "2026-09-09"
---

# Medische gegevens opslaan in je kapsalon: wat mag wél en wat niet onder de AVG?

Wanneer mensen horen dat ik als voormalig directeur van Stichting de Baan me druk maak over hoe kappers omgaan met hoofdhuidnotities en biometrische foto's, reageren sommigen verbaasd. *"Vincent, een salon is toch geen ziekenhuis?"*

Mijn antwoord aan de keukentafel is altijd hetzelfde: privacy gaat niet over wetboeken of instanties; privacy gaat over menselijke waardigheid en kwetsbaarheid. Toen ik in 2014 de corporate ratrace verliet om fulltime vader te zijn, leerde ik dat vertrouwen het meest breekbare goed is dat er bestaat. In het welzijnswerk was dat leidend voor 700 deelnemers. En in de salon is dat precies hetzelfde.

Klanten delen aan de wasbak dingen die ze soms zelfs niet aan hun naaste vrienden vertellen:
* *"Mijn haar valt met bossen uit sinds mijn chemokuur."*
* *"Ik heb pleksgewijze kaalheid (alopecia areata) en schaam me dood."*
* *"Mijn hoofdhuid zit vol bloedende eczeemplekken."*

Veel salons noteren dit soort vertrouwelijke observaties zorgvuldig in hun afsprakensysteem of maken even snel een voor- en na-foto met de salon-iPad. Wat 95% van de ondernemers niet beseft: **op dat exacte moment kwalificeert jouw salon zich juridisch als verwerker van medische gegevens onder Artikel 9 van de AVG**. En daar gelden de zwaarste Europese sancties voor.

## Het harde verbod van Artikel 9 lid 1 AVG

In de privacywetgeving bestaat geen grijs gebied voor de uiterlijke verzorging. **Artikel 9 lid 1 AVG** formuleert een categorisch verbod:

> *"De verwerking van gegevens over de gezondheid, genetische gegevens of biometrische gegevens met het oog op de unieke identificatie van een persoon is verboden."*

Er is geen algemene vrijstelling voor kappers, schoonheidsspecialisten of trichologische salons. Het argument *"ik doe dit om de klant te helpen"* is juridisch irrelevant.

Zodra je registreert dat een klant lijdt aan:
* **Alopecia** (androgenetica of areata);
* **Psoriasis capitis** of seborroïsch eczeem;
* **Haarverlies door medicatie** of oncologische behandelingen (zoals chemotherapie);
* **Trichotillomanie** (dwangmatig haartrekken);

...verwerk je formele medische data. Doe je dit zonder een waterdicht wettelijk uitzonderingsregime? Dan riskeert je salon boetes van de Autoriteit Persoonsgegevens die kunnen oplopen tot **€20.000.000 of 4% van de wereldwijde jaaromzet**.

## De gevaren van voor- en na-foto's op iPads en telefoons

Een van de grootste sluipende risico's in moderne salons is de omgang met beeldmateriaal. Stylisten fotograferen een kalende kruin vóór een haardichtheidsbehandeling of extensions, en schieten na afloop een glansrijk eindresultaat voor Instagram.

Waarom dit juridisch levensgevaarlijk is zonder strikte protocollen:

1. **Biometrische herkenbaarheid:** Een foto van een gezicht of specifiek herkenbare hoofdhuidconditie is een biometrisch persoonsgegeven én een gezondheidsgegeven in één.
2. **Onbeveiligde cloud-synchronisatie:** Wordt de foto gemaakt met een salon-iPad of privémobiel? Dan synchroniseert de foto vaak automatisch met Apple iCloud of Google Photos op Amerikaanse servers. Dit is een ongeautoriseerde internationale doorgifte van bijzondere persoonsgegevens.
3. **Het Instagram-risico:** Foto's die intern bedoeld waren voor de behandelhistorie worden soms zonder schriftelijke toestemming door een enthousiaste medewerker op social media geplaatst. Dit leidt regelmatig tot schadeclaims van geschonden cliënten.

```
[DE FOTO-COMPLIANCE MATRIX VOOR DE SALON]

Foto met herkenbaar gezicht / hoofdhuiddefect
  ├── Opgeslagen in algemene iPad filmrol  ──► DATALEK (Onversleuteld + iCloud sync)
  ├── Gedeeld op Instagram zonder release ──► CIVIELE AANSPRAKELIJKHEID & AVG-BOETE
  └── Opgeslagen in beveiligde CRM-vault   ──► CONFORM (AES-256 encryptie + Opt-in)
```

## De EU AI Act: Verbod op emotie-analyse op de werkvloer

Naast de AVG handhaaft de Europese Unie sinds begin 2025 de **EU AI Act**. Dit raakt salons die experimenteren met slimme camera's of spraaktechnologie direct.

* **Verbod op emotieherkenning (Artikel 5 lid 1 sub f):** Het is in de Europese Unie ten strengste verboden om AI-systemen in te zetten die emoties van medewerkers of klanten aflezen of analyseren op de werkplek. Onze Voice-AI en intake-software bij Kappersassistent analyseert dan ook uitsluitend wát iemand zegt (de functionele intentie), en nooit hoe emotioneel iemand klinkt.
* **Transparantieplicht (Artikel 50):** Maak je gebruik van een AI-telefonist of online intake-assistent? Dan moet de klant vóór aanvang van het gesprek weten dat zij met een geautomatiseerd systeem communiceert.

## De 5 gouden regels voor medische data in de salon

Wil je jouw cliënten de beste zorg en discretie bieden zónder angst voor toezichthouders? Pas deze vijf gouden regels toe:

1. **Vraag altijd een expliciete, afzonderlijke opt-in (Art. 9 lid 2 sub a):** Laat de klant bij het aanmaken van de intakekaart een actieve handtekening of digitaal vinkje zetten. Vraag specifiek toestemming voor het vastleggen van hoofdhuidcondities en behandelindicaties.
2. **Pseudonimiseer en maskeer gevoelige data (PII-masking):** Zorg dat medische notities niet in het algemene overzicht staan waar leveranciers of passanten op het scherm kunnen meekijken.
3. **Isoleer behandel- en intakefoto's:** Bewaar foto's nooit in de standaard fotogalerij van je telefoon. Gebruik gesloten salonsoftware met een versleutelde mediakluis (AES-256) die gehost wordt binnen de Europese Economische Ruimte (EER).
4. **Sluit verwerkersovereenkomsten met softwareleveranciers:** Controleer of jouw CRM-, kassa- en AI-leveranciers een geldige verwerkersovereenkomst hebben waarin data-isolatie en Europese hosting gegarandeerd zijn.
5. **Human-in-the-Loop waarborg:** Laat AI nooit zelfstandig medische diagnoses stellen of behandelingen voorschrijven. Zodra een klant melding maakt van open wonden of acute medische klachten, moet de software direct warm doorschakelen naar de hoofdstylist of doorverwijzen naar een arts.

Rust op de werkvloer begint bij een zuiver geweten en een waterdichte juridische basis.

---

*Vincent van Munster is sociaal ondernemer, AI-innovator en oprichter van WeAreImpact en Kappersassistent. Als voormalig welzijnsdirecteur én vader van twee kinderen bouwt hij aan AI-oplossingen met één doel: kille technologie inzetten om warme handen en kostbare tijd vrij te spelen.*

Beperkt beschikbaar voor strategische implementatie en AI-transformatie (max. 2–3 dagen per week) via WeAreImpact.nl en Kappersassistent.nl.
