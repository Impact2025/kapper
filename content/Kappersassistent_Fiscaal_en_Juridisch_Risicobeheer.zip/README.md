# Kappersassistent | Fiscaal & Juridisch Risicobeheer en Kennisbank

Beste ondernemer,

Toen ik in 2014 bewust uit de corporate ratrace stapte om fulltime vader te zijn voor mijn twee kinderen, leerde ik aan de keukentafel dat rust en vertrouwen alleen ontstaan als de basis klopt. In mijn jaren als directeur in het welzijnsdomein — waar ik verantwoordelijk was voor honderden deelnemers en vrijwilligers — zag ik wat er gebeurt als administratieve en juridische fundamenten rammelen. 

Met Kappersassistent en WeAreImpact bouw ik aan één heldere belofte: **kille technologie inzetten om warme handen aan de stoel en kostbare tijd voor je gezin vrij te spelen**. Geen ivoren-torendialoog, maar concrete oplossingen voor de fiscale en juridische risico's waar saloneigenaren 's nachts van wakker liggen.

In dit downloadpakket vind je alle uitgewerkte dossiers, modelclausules en kennisbankartikelen:

## 1. Witboeken & Strategische Documenten (PDF)
* **`Fiscaal_en_Juridisch_Risicobeheer_Kapsalon.pdf`**: Het complete 4-pagina's tellende witboek met alle 4 dossiers, berekeningen van fiscale tekorten, kantonrechter-jurisprudentie, wettelijke kaders (Tabel I post b.27 Wet OB, Artikel 9 AVG, EU AI Act), modelclausules, een 7-stappen veiligheidsprotocol en FAQ.
* **`Architectuur_Kennisbank_en_Blog_Kappersassistent.pdf`**: De complete strategische taxonomie en redactionele structuur voor de 5 kennisbankclusters van Kappersassistent.

## 2. Fiscale & Juridische Kennisbankartikelen (Markdown + YAML Frontmatter)
* **`btw-tarief-kapper-9-of-21-procent.md`**: Pure arbeid (9%) vs. retailgoederen (21%). Rekenvoorbeeld hoe een verkeerde combi-deal aanslag leidt tot €16.380+ aan naheffingsrisico's.
* **`btw-op-no-show-vergoeding-kapper.md`**: Schadevergoeding (buiten de btw / 0%) vs. reserveringsdienst (9%). Waarom 21% aanslaan een dure fout is en wat de kantonrechter Middelburg vereist.
* **`avg-regels-klantenkaart-kapsalon-allergie.md`**: Waarom het noteren van een verfallergie (PPD, ammoniak) onder Artikel 9 AVG valt en waarom de gratis WhatsApp Business app illegaal is voor klantcommunicatie.
* **`medische-gegevens-opslaan-salon-avg.md`**: Alopecia, psoriasis en chemokuren in het salon-CRM. Strikte omgang met voor-en-na-foto's, PII-masking en het verbod op emotie-AI onder de EU AI Act.

## 3. Aanvullende Thought Leadership & Operationele Artikelen (Markdown)
* **`ai-telefonist-kappers-omzetverlies-voicemail.md`**: Het dichten van de 35–40% gemiste oproepen en 85% voicemail-afhakers met sub-800ms Voice-AI.
* **`btw-splitsing-kappers-salon-software-administratie.md`**: Automatische grootboekkoppelingen via software zoals Looppiness en samenwerking met specialisten zoals Buro Burmanje.
* **`intelligent-double-booking-salon-rendement-inwerktijden.md`**: 20–35% extra marge door geautomatiseerde benutting van chemische inwerktijden.
* **`avg-artikel-9-ai-kappers-gezondheidsgegevens.md`**: Privacy by Design en de overstap naar de officiële WhatsApp Business API via WATI.
* **`n8n-salon-automatisering-whatsapp-crm-koppeling.md`**: Open-source n8n-orkestratie tussen spraak, chat, agenda en boekhouding.
* **`no-show-beleid-kappers-middelburg-uitspraak.md`**: Juridisch afdwingbare no-show procedures met actieve checkboxes.
* **`voice-ai-telefonie-latentie-sub-800ms-kappers.md`**: De techniek achter Deepgram Flux en Cartesia Sonic 3.5 voor natuurlijke telefoondialoog.

---

*Vincent van Munster is sociaal ondernemer, AI-innovator en oprichter van WeAreImpact en Kappersassistent. Als voormalig welzijnsdirecteur én vader van twee kinderen bouwt hij aan AI-oplossingen met één doel: kille technologie inzetten om warme handen en kostbare tijd vrij te spelen.*

Zullen we eens koffie drinken? Als ondernemer en vader hoor ik graag waar jouw salonpraktijk vandaag de dag écht vastloopt.
