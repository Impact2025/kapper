---
title: "AVG-regels voor de klantenkaart: waarom een verfallergie registreren riskant is"
slug: "avg-regels-klantenkaart-kapsalon-allergie"
category: "kennisbank"
focus_keyphrase: "avg regels klantenkaart kapsalon allergie"
meta_description: "Mag je een allergie voor haarverf of PPD zomaar noteren op de klantenkaart? Ontdek de strikte AVG-eisen, patch-test regels en gevaren van WhatsApp."
author: "Vincent van Munster"
date: "2026-09-09"
---

# AVG-regels voor de klantenkaart: waarom een verfallergie registreren riskant is

Wanneer mensen horen dat ik als oud-bestuurder in de maatschappelijke zorg saloneigenaren waarschuw voor privacyboetes over een simpele verfnotitie, kijken ze me soms met ongeloof aan. *"Vincent, ik noteer toch alleen maar dat mevrouw De Vries jeuk krijgt van blondeerpoeder? Dat is toch juist goede service?"*

Mijn antwoord aan de keukentafel is altijd hetzelfde: goede bedoelingen beschermen je niet tegen wetsovertredingen. In 2014 stapte ik bewust uit de corporate ratrace om fulltime vader te zijn voor mijn twee kinderen. Als ouder leer je snel: zorgzaamheid zonder duidelijke grenzen leidt tot ongelukken. En in mijn tien jaar als directeur in het sociaal domein zag ik hoe inspecties en toezichthouders genadeloos optreden zodra organisaties slordig omspringen met vertrouwelijke gegevens van burgers.

In de kapperswereld gebeurt iets fascinerends. De salonstoel is een van de weinige plekken waar klanten zich letterlijk blootgeven. Ze vertellen je over een branderige hoofdhuid, blaren na een eerdere kleurbehandeling, of een extreme overgevoeligheid voor PPD (parafenyleendiaminen). 

Als vakvrouw of vakman wil je letsel voorkomen, dus noteer je het meteen op de klantenkaart. Maar zodra je dat doet, begeef je je juridisch gezien op glad ijs: **je verwerkt medische gezondheidsgegevens onder de AVG**.

## De scheidslijn: gewone versus bijzondere persoonsgegevens

Onder de Algemene Verordening Gegevensbescherming (AVG) bestaan persoonsgegevens in twee categorieën:

1. **Gewone persoonsgegevens (Artikel 6 AVG):** Naam, adres, telefoonnummer, e-mailadres en de datum van de laatste knipbeurt. De wettelijke grondslag hiervoor is simpel: *Noodzakelijk voor de uitvoering van de overeenkomst*. Hier heb je geen ingewikkelde toestemmingsformulieren voor nodig.
2. **Bijzondere persoonsgegevens (Artikel 9 AVG):** Gegevens over iemands gezondheid, allergieën, fysiologische aandoeningen of biometrie. 

Het registreren dat een klant allergisch is voor ammoniak, eczeem heeft bij de haarlijn, of een reactie vertoont bij een patch-test, valt **100% onder gegevens over de gezondheid**. 

En voor Artikel 9 geldt een keihard wettelijk principe: **het verwerken van deze gegevens is in de basis VERBODEN**, tenzij er sprake is van een zeer specifieke wettelijke uitzondering.

```
[DE JURIDISCHE REALITEIT VAN DE KLANTENKAART]

Klantgegevens (Naam, 06-nummer, Coupe) ──► Art. 6 AVG (Overeenkomst)   ──► TOEGRESTAN
Allergieën (PPD, Ammoniak, Blaren)     ──► Art. 9 AVG (Gezondheidsdata) ──► VERBODEN
                                           │
                                           └─► Enige geldige uitzondering:
                                               EXPLICIETE, AFZONDERLIJKE TOESTEMMING
```

## Waarom "goed voor de klant" juridisch faalt

Veel kappers denken: *"Maar ik moet dit toch opslaan om te voorkomen dat haar hoofdhuid verbrandt? Dat is toch mijn gerechtvaardigd belang of wettelijke zorgplicht?"*

Helaas: de grondslag *Gerechtvaardigd belang (Art. 6 lid 1 sub f)* geldt **nooit** voor gezondheidsgegevens onder Artikel 9. De enige uitzondering waarop een commerciële salon zich rechtsgeldig kan beroepen, is **Artikel 9 lid 2 sub a AVG: de uitdrukkelijke, aantoonbare toestemming van de betrokkene**.

Heeft jouw klant geen specifiek vinkje gezet of handtekening geplaatst waarmee zij jou expliciet autoriseert om haar allergieën en reacties op te slaan? Dan is de notitie op je klantenkaart formeel illegaal. Bij een datalek of een inspectie door de Autoriteit Persoonsgegevens (AP) sta je met lege handen.

## De valkuil van de gratis WhatsApp Business app

Het grootste datalek in de uiterlijke verzorging vindt momenteel plaats via WhatsApp. Een klant appt op zaterdagavond: *"Hoi, mijn nek is helemaal rood geworden na het verven gisteren, zie deze foto."* De kapper reageert: *"Oei, ik zet het op je kaart, volgende keer ammoniakvrij!"*

Als dit gebeurt via de **gratis WhatsApp Business app** op een mobiele telefoon van de zaak of privé, overtreed je de privacywetgeving op twee ernstige punten:

1. **Gedwongen adresboek-synchronisatie:** De gratis app uploadt continu alle contacten uit het telefoonboek naar servers van Meta in de Verenigde Staten, zonder dat deze contactpersonen daar ooit toestemming voor hebben gegeven.
2. **Meta's Regulated Verticals beleid:** Meta verbiedt in haar eigen gebruiksvoorwaarden uitdrukkelijk het verzenden en verwerken van medische en gezondheidsgegevens via de standaard gratis app.

De enige AVG-conforme oplossing is het gebruik van de officiële **WhatsApp Business API** (gekoppeld via enterprise-infrastructuur zoals WATI). Hierbij worden geen adresboeken uitgelezen en blijft alle data veilig binnen de Europese Economische Ruimte (EER) met end-to-end encryptie.

## Het 4-stappenplan voor een veilige klantenkaart

Wil je met een gerust hart allergietesten en gevoeligheden vastleggen? Voer vandaag nog deze vier maatregelen in:

* **Stap 1: Scheid de toestemming bij de online intake:** Verstop de toestemming voor allergieën nooit in je algemene voorwaarden. Maak een aparte, niet-vooraangevinkte checkbox:  
  *`[ ] Ik geef [Salonnaam] uitdrukkelijk toestemming om gegevens over eventuele allergieën en hoofdhuidreacties vast te leggen om behandelingen veilig uit te voeren.`*
* **Stap 2: Beperk de toegang (Role-Based Access Control):** Zorg dat niet elke zaterdaghulp of stagiair in de kassa zomaar medische notities kan inzien. Gezondheidsdata hoort afgeschermd te zijn voor niet-behandelend personeel.
* **Stap 3: Hanteer dataminimalisatie:** Noteer uitsluitend wat strikt noodzakelijk is voor de kleurbehandeling. Niet: *"Mevrouw heeft last van ernstige psoriasis door stress thuis"*, maar: *"Gevoelige hoofdhuid; geen peroxide >6% gebruiken, ammoniakvrij werken."*
* **Stap 4: Richt het recht op vergetelheid in:** Vraagt een klant om verwijdering van haar profiel? Zorg dat je software niet alleen haar telefoonnummer wist, maar ook alle historische allergiedossiers en foto's onherroepelijk vernietigt.

Kille technologie en strakke regels aan de achterkant, zodat jij met warme handen en volle focus aan de stoel kunt blijven werken.

---

*Vincent van Munster is sociaal ondernemer, AI-innovator en oprichter van WeAreImpact en Kappersassistent. Als voormalig welzijnsdirecteur én vader van twee kinderen bouwt hij aan AI-oplossingen met één doel: kille technologie inzetten om warme handen en kostbare tijd vrij te spelen.*

Zullen we eens koffie drinken? Als ondernemer en vader hoor ik graag waar jouw salonpraktijk vandaag de dag écht vastloopt.
