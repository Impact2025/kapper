---
title: "Btw op de no-show vergoeding bij de kapper: schadevergoeding of 9% prestatie?"
slug: "btw-op-no-show-vergoeding-kapper"
category: "kennisbank"
focus_keyphrase: "btw op no show vergoeding kapper"
meta_description: "Moet je 0%, 9% of 21% btw heffen op een no-show vergoeding in de kapsalon? Lees wat het Europese Hof en de kantonrechter bepalen over annuleringskosten."
author: "Vincent van Munster"
date: "2026-09-09"
---

# Btw op de no-show vergoeding bij de kapper: schadevergoeding of 9% prestatie?

Wanneer mensen horen dat ik als oud-bestuurder in de zorg urenlang kan praten over annuleringskosten en btw-heffing bij wegblijvende klanten, kijken ze me weleens verbaasd aan. Want: Vincent en no-show jurisprudentie?

Mijn antwoord aan de keukentafel is altijd hetzelfde: respect voor elkaars tijd is de basis van elke gezonde relatie. In 2014 stapte ik bewust uit de corporate ratrace om er onvoorwaardelijk voor mijn twee kinderen te zijn. Tijd is het enige bezit dat je nooit meer kunt terugkopen. In een kapsalon is tijd letterlijk de voorraad op de plank. Een tube kleurspoeling die vandaag niet opengaat, bewaar je voor volgende week. Maar een leeg uur door een klant die zonder bericht wegblijft voor een balayage van €150, is omzet die definitief verdampt.

Voor een gemiddelde salon met vier stoelen loopt de schade door no-shows jaarlijks op tot zo'n **€12.000**. Steeds meer ondernemers sturen daarom — terecht — een factuur of incasseren een vergoeding via een aanbetaling. Maar op het moment dat je die no-show boekt in de kassa, ontstaat de grote fiscale verwarring: **welk btw-tarief moet je toepassen? 0%, 9% of 21%?**

Sla je dit verkeerd aan, dan draag je te veel belasting af aan de schatkist, óf je riskeert bij een audit een naheffing wegens ten onrechte niet-afgedragen omzetbelasting.

## De Europese hoofdregel: schadevergoeding is onbelast (0% BTW)

Volgens vaste jurisprudentie van het **Hof van Justitie van de Europese Unie (HvJ EU)** — met name het richtinggevende arrest *Société thermale d’Eugénie-les-Bains* (zaak C-277/05) — is een zuivere schadevergoeding **niet onderworpen aan de btw**.

De juridische redenering is glashelder: omzetbelasting kan uitsluitend worden geheven wanneer er sprake is van een *rechtstreeks verband* tussen een geleverde prestatie (het knippen) en een ontvangen tegenprestatie (de betaling). 

Wanneer een klant niet komt opdagen:
1. Heeft de salon géén kappersdienst verleend;
2. Krijgt de klant géén tegenprestatie of consumptief voordeel;
3. Dient het ingehouden bedrag uitsluitend om het geleden verlies door de leegstaande stoel en gederfde winst te compenseren.

Als jouw salonvoorwaarden de vergoeding expliciet kwalificeren als een **"gefixeerde schadevergoeding wegens contractbreuk"**, valt dit bedrag **buiten het bereik van de Wet op de omzetbelasting (0% btw)**. Je draagt hierover dus géén btw af.

## De fiscale valkuil: wanneer de Belastingdienst wél 9% opeist

Toch waarschuwen gespecialiseerde kapperaccountants (zoals Buro Burmanje) voor een gevaarlijke nuance in het Nederlandse belastingrecht. 

Als jouw salon in haar communicatie of algemene voorwaarden termen gebruikt zoals:
* *"Vergoeding voor het gereserveerde tijdslot"*
* *"Betaling voor de beschikbaarheid van de stylist"*
* *"Annuleringskosten voor het vasthouden van de stoelcapaciteit"*

...dan stelt de inspecteur van de Belastingdienst zich vaak op het standpunt dat er wél een belastbare prestatie is geleverd. De prestatie is in dat geval niet het knippen zelf, maar **het beschikbaar houden van saloncapaciteit**. Omdat deze prestatie onlosmakelijk verbonden is met het kappersvak, eist de fiscus in dat geval **9% btw**.

```
[DE JURIDISCHE KEUZE IN JE ALGEMENE VOORWAARDEN]

Variant A: "Gefixeerde schadevergoeding wegens wanprestatie"
──► Geen prestatie geleverd ──► Buiten de btw (0%) ──► Geen afdracht

Variant B: "Reserveringsvergoeding voor stoel en stylist"
──► Dienst is beschikbaarheid ──► Belast met 9% BTW ──► Afdracht verplicht
```

## De 21% blunder die salons duizenden euro's kost

Veel kapsalons die op eigen houtje een no-show module inrichten, selecteren in hun kassasysteem gemakshalve de knop *"Overige inkomsten (21%)"*. Dat is een kostbare denkfout:

1. Als het een schadevergoeding is (0%), schenk je 21% van je compensatiebedrag zomaar weg aan de fiscus.
2. Was de geplande afspraak een knip- of kleurbehandeling (normaal 9%) en de fiscus kwalificeert het als stoelreservering, dan betaal je ruim 12% te veel belasting over je gemiste inkomsten.
3. Alleen wanneer de gereserveerde afspraak betrekking had op **retailproducten of visagie**, zou een 21%-tarief aan de orde kunnen zijn.

| Kwalificatie in Voorwaarden | Btw-regime | Btw-percentage | Motivering voor Belastingdienst |
| :--- | :--- | :--- | :--- |
| **Gefixeerde schadevergoeding** | Buiten bereik Wet OB | **0%** | Conform HvJ EU arrest Eugénie-les-Bains; geen prestatie. |
| **Reserveringsvergoeding** | Belaste dienst | **9%** | Beschikbaarstelling van kapperstijd; volgt hoofdprestatie. |
| **Pakket inclusief gereserveerde retail** | Gesplitste post | **0% / 9% / 21%** | Alleen toepassen bij vooraf klaargemaakte goederen. |
| **Verkeerde verzamelpost (Fout)** | Onjuist tarief | **21%** | Salon draagt onnodig te veel belasting af. |

## De link met de kantonrechter Middelburg: zonder vinkje geen incasso

Of je nu kiest voor een schadevergoeding van 0% of een reserveringsvergoeding van 9%, de vergoeding is juridisch **volstrekt oninbaar** als je boekingsstraat niet op orde is.

De kantonrechter in Middelburg wees vorderingen van salons tegen wegblijvers genadeloos af wanneer de salon werkte met een bordje bij de kassa of een tekstje onderaan de website. De rechter eist **expliciete wilsovereenstemming** vóór het sluiten van de boeking.

Wil je jouw no-show fee veilig kunnen factureren of automatisch inhouden via Stripe of Mollie? Zorg dan voor:
1. Een **actieve, niet-aangevinkte checkbox** bij het online boeken waarin de klant instemt met het annuleringsprotocol;
2. Een glasheldere bepaling: *"Bij annulering korter dan 24 uur voor de afspraak brengen wij een gefixeerde schadevergoeding van 50% in rekening ter compensatie van de leegstaande behandelstoel."*
3. Een geautomatiseerde **SMS-herinnering 24 uur vooraf** via Kappersassistent: hiermee daalt je totale uitval direct van 8% naar minder dan 2%, waardoor je die no-show factuur in 98% van de gevallen niet eens hoeft te sturen.

Rust in je agenda, een waterdichte administratie en geen cent te veel naar de fiscus.

---

*Vincent van Munster is sociaal ondernemer, AI-innovator en oprichter van WeAreImpact en Kappersassistent. Als voormalig welzijnsdirecteur én vader van twee kinderen bouwt hij aan AI-oplossingen met één doel: kille technologie inzetten om warme handen en kostbare tijd vrij te spelen.*

Zullen we eens koffie drinken? Als ondernemer en vader hoor ik graag waar jouw salonpraktijk vandaag de dag écht vastloopt.
