---
title: "Het mysterie van de lege stoel: waarom inwerktijd je grootste verborgen winstbron is"
slug: "intelligent-double-booking-salon-rendement-inwerktijden"
category: "blog"
focus_keyphrase: "stoelbezetting kapsalon optimaliseren"
meta_description: "Laat jij ook 45 minuten omzet liggen tijdens het inwerken van een balayage? Leer hoe Intelligent Double-Booking je stoelwinst met 30% verhoogt."
author: "Vincent van Munster"
date: "2026-09-09"
---

# Het mysterie van de lege stoel: waarom inwerktijd je grootste verborgen winstbron is

Toen ik nog leidinggaf aan Stichting de Baan, met 700 deelnemers en 180 vrijwilligers, leerde ik één ding heel snel: capaciteit is een illusie als je planning star is. Je kunt op papier genoeg mensen en middelen hebben, maar als de overdracht rammelt, ontstaat er overal leegloop en stress.

Toen ik me ging verdiepen in de salonbranche, viel mijn mond open. Ik zag getalenteerde stylisten die zich een slag in de rondte werkten, maar aan het einde van de maand onder de streep bitter weinig overhielden. 

De oorzaak? Het slechtst bewaarde geheim van de kapperswereld: **de onbenutte inwerktijd**.

## De bottleneck van het klassieke afsprakenboek

Kijk eens eerlijk naar hoe een complexe kleurbehandeling — laten we zeggen een uitgebreide balayage met toner — traditioneel in de agenda staat:

* **10:00 - 10:45:** Intake, folies zetten, aanbrengen ontkleuring (Stylist 100% bezig)
* **10:45 - 11:30:** Inwerktijd onder de warmtelamp (Klant drinkt koffie; stylist ruimt wat op of scrolt op telefoon)
* **11:30 - 12:15:** Uitspoelen, toner aanbrengen, knippen en stylen (Stylist 100% bezig)

In het traditionele model reserveert de stylist een blok van 2 uur en 15 minuten in de salonsoftware. Maar gedurende die 45 minuten inwerktijd brengt de stoel géén actieve omzet op, terwijl de vaste salonlasten — van huur en energie tot personeelskosten — gewoon doortikken. 

Een menselijke receptionist durft in die tussentijd vaak niets in te plannen uit angst dat behandelingen uitlopen. En als de kapper zelf zijn agenda beheert, schiet het er bij de hectiek aan de wasbak simpelweg bij in.

```
45 minuten verloren inwerktijd × 3 kleuringen per dag per stylist = 2 uur en 15 minuten onbenutte capaciteit. 
Per stoel is dat een structureel productiviteitsverlies van ruim 25% tot 40%.
```

## Wat is Intelligent Double-Booking?

Dit is exact waar agentic software het verschil maakt. Met **Intelligent Double-Booking** splitsen we elke complexe behandeling in onze database op in drie dynamische fasen:

1. **Fase 1 (Hands-on):** Intake & applicatie (stylist strikt bezet).
2. **Fase 2 (Processing/Inwerktijd):** Chemische inwerktijd van verf of permanent (klant bezet een stoel/droogkap, maar de handen van de stylist zijn vrij).
3. **Fase 3 (Hands-on):** Wassen, snijden, fohnen en afrekenen (stylist strikt bezet).

Zodra een klant via onze Voice-AI of chatbot een kleursessie boekt, herkent het algoritme automatisch het "gat" van Fase 2. Het systeem stelt dat specifieke tijdslot proactief beschikbaar voor behandelingen die exact in die tussenruimte passen: een herensnit van 30 minuten, een kinderknipper of het epileren van wenkbrauwen.

```
[ STYLIST AGENDA ]
10:00 ─── Balayage Applicatie (Klant A) ─── 10:45
10:45 ─── [INWERKTIJD KLANT A] ─────────── 11:30
          └─ Heren Knippen (Klant B) ─┘ (10:50 - 11:20)
11:30 ─── Uitspoelen & Styling (Klant A) ── 12:15
```

## Rendement zonder burn-out

Sommige saloneigenaren zijn huiverig: *"Raakt mijn personeel hierdoor niet overwerkt?"* 

Mijn ervaring als bestuurder is: mensen raken niet overspannen van helder gestructureerd werk; ze raken overspannen van chaos, ad-hoc geschuif en een rinkelende telefoon aan hun hoofd. 

Intelligent Double-Booking creëert juist voorspelbaarheid. Het systeem houdt strikt rekening met bufferzones en voorkomt dat er een ingewikkelde knipbeurt in een te krap slot wordt gepropt. De stylist weet precies waar hij aan toe is, de klant in de inwerktijd voelt zich niet verlaten (want het is van tevoren helder gecommuniceerd), en de extra klant kan nog dezelfde ochtend terecht.

Het zakelijke effect is spectaculair: salons die overstappen op intelligente capaciteitsbenutting zien hun **omzet per stoel met 20% tot 35% stijgen**, zonder dat er één vierkante meter salonruimte of één fulltime medewerker bij hoeft te komen. 

Dat noem ik nou: slimmer bouwen met de spullen die je al hebt.

---

*Vincent van Munster is sociaal ondernemer, AI-innovator en oprichter van WeAreImpact en Kappersassistent. Als voormalig welzijnsdirecteur én vader van twee kinderen bouwt hij aan AI-oplossingen met één doel: kille technologie inzetten om warme handen en kostbare tijd vrij te spelen.*

Zullen we eens koffie drinken? Als ondernemer en vader hoor ik graag waar jouw salonpraktijk vandaag de dag écht vastloopt.