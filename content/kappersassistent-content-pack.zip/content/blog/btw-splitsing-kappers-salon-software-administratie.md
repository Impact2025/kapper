---
title: "De btw-valkuil aan de kassa: hoe een verkeerde procentberekening je salonwinst opeet"
slug: "btw-splitsing-kappers-salon-software-administratie"
category: "blog"
focus_keyphrase: "btw tarief kapper 9 procent 21 procent"
meta_description: "Voorkom naheffingen van de Belastingdienst. Ontdek hoe je de 9% en 21% btw-splitsing in je salon volledig automatiseert en 10 uur per week bespaart."
author: "Vincent van Munster"
date: "2026-09-09"
---

# De btw-valkuil aan de kassa: hoe een verkeerde procentberekening je salonwinst opeet

Wanneer mensen horen dat ik als voormalig directeur van Stichting de Baan me druk maak over kassa-aanslagen en btw-tarieven in de kapsalon, kijken ze me soms glimlachend aan. Maar wie ooit verantwoordelijk is geweest voor een stichting met tonnen aan publieke subsidies en honderden vrijwilligers, weet: als de administratieve basis rammelt, dondert vroeg of laat het hele kaartenhuis in elkaar.

In een kapsalon zie ik ondernemers met een fantastisch creatief oog dagelijks worstelen met een fiscale nachtmerrie die hen uren aan nachtrust kost: **het Nederlandse dubbele btw-tarief**.

Terwijl je aan de stoel staat te knippen, verkoop je een shampoo voor thuisverzorging. Twee handelingen binnen dezelfde minuut, aan dezelfde klant, maar met een totaal verschillend fiscaal regime. En wie dat aan het einde van de dag handmatig op een telrolletje of in Excel moet rechtbreien, verliest kostbare tijd die eigenlijk naar het gezin of naar ontspanning hoort te gaan.

## De 9% versus 21% splitsing: waar het stelselmatig misgaat

In Nederland geldt voor het kappersambacht een verlaagd btw-tarief om arbeid te stimuleren:

* **9% BTW:** Is exclusief van toepassing op de pure arbeidscomponent van de kappersdienst: het knippen, wassen, kleuren, föhnen en stylen van het haar.
* **21% BTW:** Is van toepassing op álle fysieke goederen die de salon verlaten: stylingproducten, shampoos, borstels, haaraccessoires én administratieve opslagen.

Wat gebeurt er in de praktijk? Een klant rekent €85 af: €60 voor de knip- en kleurbeurt (9%) en €25 voor een professionele conditioner (21%). Veel verouderde kassasystemen slaan dit aan als één verzamelpost "Diensten & Verkoop". 

Bij de kwartaalaangifte moet de boekhouder dit handmatig ontrafelen. Gevolg: torenhoge facturen van de accountant, of — nog erger — een foute schatting waardoor je bij een controle van de Belastingdienst direct een naheffingsaanslag met boete aan je broek krijgt.

```
Foutieve aanslag: €85 volledig belast tegen 9% = €7,02 afgedragen btw.
Wettelijk verplicht: (€60 / 1.09 × 0.09) + (€25 / 1.21 × 0.21) = €4,95 + €4,34 = €9,29 af te dragen btw.
Verschil per klant: €2,27 te weinig afgedragen. Bij 250 klanten per maand is dat €6.810 per jaar aan fiscaal risico.
```

## Het no-show dilemma: welk btw-tarief reken je bij een wegblijver?

De verwarring wordt compleet bij het factureren van no-shows. Als een klant niet komt opdagen voor een afspraak van €100 en je brengt conform je annuleringsprotocol 50% in rekening, welk btw-tarief pas je dan toe?

De wet is hier kraakhelder: **een no-show vergoeding is een schadevergoeding die de oorspronkelijk beoogde prestatie weerspiegelt**. 
* Betrof de gemiste afspraak puur knippen of kleuren? Dan factureer je de no-show fee tegen **9% BTW**.
* Had de klant ook specifieke verzorgingsproducten gereserveerd of breng je administratiekosten in rekening? Dan moet dat specifieke deel tegen **21% BTW** worden geboekt.

Sla je dit blind aan onder 21%, dan betaal je te veel belasting aan de fiscus. Sla je het blind aan onder 0% (vrijgesteld van btw), dan riskeer je een boete bij een audit.

## De oplossing: een gesloten ecosysteem zonder handmatige exports

Administratieve rust bereik je pas wanneer je kassa, agenda en boekhouding realtime met elkaar praten. Stop met het exporteren van CSV-bestanden aan het einde van de maand!

Binnen onze adviespraktijk zien we dat salons die overstappen op software met een **geïntegreerde boekhoudmodule** (zoals het Nederlandse **Looppiness**) hun administratieve frictie met 90% verminderen. Looppiness is momenteel een van de weinige platforms die de btw-splitsing per transactiegegeven direct doorrekent naar de grootboekrekeningen, waardoor dagomzetten audit-proof worden vastgelegd. 

En voor salons die werken met externe fiscale specialisten — zoals het gerenommeerde **Buro Burmanje**, dat gespecialiseerd is in de cijfers van de kappersbranche — levert deze data-integriteit een directe besparing op: de accountant hoeft geen rommel meer op te schonen, waardoor je duizenden euro's aan advieskosten bespaart.

De som van dit alles? **Tot wel 10 uur per week minder administratief zwoegen**. Tijd die niet opgaat aan bonnetjes en rekenmachines, maar aan vakmanschap, inspiratie, of gewoon op tijd thuis zijn voor het avondeten.

---

*Vincent van Munster is sociaal ondernemer, AI-innovator en oprichter van WeAreImpact en Kappersassistent. Als voormalig welzijnsdirecteur én vader van twee kinderen bouwt hij aan AI-oplossingen met één doel: kille technologie inzetten om warme handen en kostbare tijd vrij te spelen.*

Zullen we eens koffie drinken? Als ondernemer en vader hoor ik graag waar jouw salonpraktijk vandaag de dag écht vastloopt.