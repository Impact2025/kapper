---
title: "De wet van 250 milliseconden: waarom trage spraakrobots je salonklanten wegjagen"
slug: "voice-ai-telefonie-latentie-sub-800ms-kappers"
category: "kennisbank"
focus_keyphrase: "voice ai telefonie salon latentie"
meta_description: "Waarom 250 milliseconden het verschil maakt tussen een trouwe klant en een verbroken verbinding. Ontdek de techniek achter sub-800ms Voice-AI voor salons."
author: "Vincent van Munster"
date: "2026-09-09"
---

# De wet van 250 milliseconden: waarom trage spraakrobots je salonklanten wegjagen

Wanneer mensen horen dat ik als oud-welzijnsbestuurder tot diep in de nacht sleutel aan State Space Models en streaming audiobuffers, kijken ze me soms meewarig aan. Want: Vincent en milliseconden-architectuur?

Mijn antwoord aan de keukentafel is altijd hetzelfde: communicatie is pas menselijk als het ritme klopt. In 2014 stapte ik bewust uit de ratrace om er thuis voor mijn kinderen te zijn. Aan de eettafel voel je het direct als iemand mentaal afwezig is: een onnatuurlijke stilte van twee seconden slaat een gesprek meteen dood. In een telefoongesprek met je salon gebeurt exact hetzelfde.

Als een klant belt om een afspraak te verzetten, belt diegene niet naar een helpdesk van een multinational. Ze bellen hún stylist. Als er dan een houterige robotstem klinkt die na elke zin drie seconden moet "nadenken" terwijl servers in de VS data heen en weer sturen, treedt direct de zogeheten *uncanny valley* op: de beller voelt instinctieve weerstand, raakt geïrriteerd en verbreekt de verbinding. 

Onderzoek toont aan dat elke 100 milliseconden aan extra vertraging de uiteindelijke conversie met maar liefst 8% verlaagt. Snelheid is bij Voice-AI geen technische gimmick; het is een randvoorwaarde voor vertrouwen.

## De anatomie van de conversatie: de 800ms-grens

In de neurowetenschap en telecommunicatie geldt een harde wet: het menselijk brein ervaart een reactietijd onder de 800 milliseconden (sub-800ms) als een natuurlijk, vlot gesprek. Duurt het langer dan 1.000 milliseconden, dan valt de illusie van een vloeiende dialoog in duigen en voelt het als een statisch keuzemenu.

Om binnen die magische 800 milliseconden te blijven, moet de hele keten — van luisteren tot begrijpen en terugspreken — feilloos synchroon lopen:

```
Beller spreekt ➔ Speech-to-Text (STT) ➔ LLM Redenering ➔ Text-to-Speech (TTS) ➔ Audio terug
    [ <150ms ]           [ ~300ms ]            [ <100ms ]       = Totaal <600-800ms
```

| Component | Traditionele Oplossing | Onze Kappersassistent Stack | Impact op Gesprek |
| :--- | :--- | :--- | :--- |
| **STT (Luisteren)** | Whisper batch processing (~1.200ms) | **Deepgram Flux Multilingual** (~150ms) | Begrijpt direct dialect en vaktermen |
| **LLM (Redeneren)** | Logge multi-prompts (~800ms) | **GPT-4o / 4o-mini streaming** (~250-350ms) | Directe intentieherkenning en agenda-check |
| **TTS (Spreken)** | Cloud TTS / WaveNet (>400ms) | **Cartesia Sonic 3.5 (SSM)** (<40-90ms TTFA) | Geen mechanische pauzes vóór antwoord |
| **Totale Latentie** | **2.500ms - 3.500ms (Onbruikbaar)** | **550ms - 750ms (Real-time)** | Beller ervaart een natuurlijk gesprek |

## Waarom wij bouwen op Cartesia Sonic en Deepgram Flux

Om deze extreme snelheden te halen zonder in te boeten op Nederlandse uitspraakkwaliteit, maken we fundamentele keuzes in de technologie:

1. **State Space Models (Cartesia):** Waar traditionele AI-stemmen werken met zware neurale netwerken die complete zinnen moeten bufferen, gebruikt Cartesia Sonic 3.5 State Space Models (SSM). Het resultaat is een Time-to-First-Audio (TTFA) van minder dan 40 tot 90 milliseconden en een Quality ELO-score van 1.210. Het eerste woord rolt al over de lijn terwijl de rest van de zin nog wordt gegenereerd.
2. **Native Code-Switching (Deepgram):** In een salon gooit een klant moeiteloos vaktermen door het Nederlands: *"Doe mij maar een balayage met een toner en een blow-dry."* Waar traditionele modellen struikelen en hallucineren, vangt het multilinguale model van Deepgram deze termen native op via gerichte language hints.
3. **Barge-in & Interruption Handling:** Niets is zo frustrerend als een spraakcomputer die doordendert terwijl jij allang zegt: *"Nee wacht, ik bedoel volgende week!"* Onze architectuur is *full-duplex*: zodra de klant interrumpeert, kapt de audio-output binnen milliseconden af en schakelt het model direct over naar luisteren.

## De Human-in-the-Loop: SIP REFER als vangnet

Geen enkele technologie is alwetend, en dat pretenderen we ook niet. Wanneer een klant belt met een gecompliceerde vraag over een chemische behandeling of een hoofdhuidconditie, dwingt onze ethiek tot een veilige escalatie. 

Via het telecomprotocol **SIP REFER** kan onze spraakagent het gesprek fysiek teruggeven aan het telefoonnetwerk en warm doorschakelen naar jouw mobiel of de balie. De stylist ziet op het scherm direct de samenvatting van wat er al besproken is. Geen herhaling, geen frictie. 

Kille techniek die razendsnel werkt, puur zodat jij ontspannen je vak kunt uitoefenen.

---

*Vincent van Munster is sociaal ondernemer, AI-innovator en oprichter van WeAreImpact en Kappersassistent. Als voormalig welzijnsdirecteur én vader van twee kinderen bouwt hij aan AI-oplossingen met één doel: kille technologie inzetten om warme handen en kostbare tijd vrij te spelen.*

Zullen we eens koffie drinken? Als ondernemer en vader hoor ik graag waar jouw salonpraktijk vandaag de dag écht vastloopt.