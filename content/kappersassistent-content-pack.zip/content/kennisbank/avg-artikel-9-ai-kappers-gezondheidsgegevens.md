---
title: "De flinterdunne grens tussen een allergietest en een datalek van duizenden euro's"
slug: "avg-artikel-9-ai-kappers-gezondheidsgegevens"
category: "kennisbank"
focus_keyphrase: "avg artikel 9 kappers bijzondere persoonsgegevens"
meta_description: "Is een foto van een hoofdhuidconditie of verfallergie medische data? Ontdek de gevaren van Artikel 9 AVG en de EU AI Act voor moderne salons."
author: "Vincent van Munster"
date: "2026-09-09"
---

# De flinterdunne grens tussen een allergietest en een datalek van duizenden euro's

Wanneer mensen horen dat ik als oud-bestuurder in de zorg nu kappers en klinieken adviseer over data-encryptie en de EU AI Act, fronsen ze weleens de wenkbrauwen. Want: wat heeft een balayage of knipbeurt te maken met strenge Brusselse wetgeving?

Alles. Mijn hele loopbaan staat in het teken van het beschermen van kwetsbaarheid. En wat veel ondernemers zich niet realiseren, is dat een salonbalie of digitale behandelkaart een van de meest intieme plekken van Nederland is. Klanten vertrouwen je niet alleen hun haar toe, maar vertellen over alopecia na een chemokuur, hormonale haaruitval, eczeem, of heftige allergische reacties op PPD in haarverf.

In het vak noemen we dat service en vakkennis. In de wet heet dat: **bijzondere persoonsgegevens onder Artikel 9 van de AVG**. En wie daar nonchalant mee omgaat, riskeert niet alleen het consumentenvertrouwen, maar speelt met torenhoge boetes.

## Wanneer wordt saloninformatie medische data?

Een gewone klantenlijst met voor- en achternaam, telefoonnummer en e-mailadres valt onder 'gewone persoonsgegevens'. Hierop is de grondslag *Uitvoering van de overeenkomst* van toepassing. Maar zodra je aantekeningen maakt om letsel te voorkomen of advies te geven, kantelt het juridische regime direct:

* **Allergieën en patch-testen:** Zodra je registreert dat een klant allergisch reageert op blondeerpoeder of ammoniak, verwerk je gezondheidsdata.
* **Hoofdhuidcondities:** Notities over psoriasis, alopecia areata of contacteczeem vallen onherroepelijk onder Artikel 9 AVG.
* **Voor-en-na-foto's:** Een detailfoto van een kale plek of beschadigde hoofdhuid bevat biometrische en medische kenmerken.

> **Cruciaal:** Voor Artikel 9-gegevens mag *'Gerechtvaardigd belang'* NOOIT als wettelijke grondslag dienen. Je mag deze data uitsluitend opslaan als de klant daarvoor een **expliciete, gedocumenteerde en afzonderlijke opt-in** heeft gegeven. Zonder die specifieke handtekening of digitale vink is je complete klantenarchief juridisch besmet.

| Gegevenstype | AVG-Classificatie | Juridische Grondslag | Verplicht Beveiligingsregime |
| :--- | :--- | :--- | :--- |
| Naam, Mobiel, E-mail | Gewoon persoonsgegeven | Noodzakelijk voor overeenkomst (Art. 6.1.b) | TLS-encryptie, gehashte opslag |
| Allergieën & Kleurreacties | **Bijzonder (Gezondheid)** | **Expliciete toestemming (Art. 9.2.a)** | AES-256 encryptie + PII-masking |
| Hoofdhuidcondities (Alopecia/Psoriasis) | **Bijzonder (Gezondheid)** | **Expliciete toestemming (Art. 9.2.a)** | Rollenbeperking (alleen behandelaar) |
| Voor- en na-foto's | **Bijzonder (Biometrisch/Gezondheid)** | **Expliciete toestemming (Art. 9.2.a)** | Geïsoleerde vault, direct intrekbaar |

## Waarom de gratis WhatsApp Business App verboden terrein is

Veel kappers communiceren via de gratis WhatsApp Business-app op hun smartphone. Begrijpelijk, want het werkt snel. Maar het is een tikkende compliance-tijdbom:

1. **Gedwongen adresboek-upload:** De gratis app dwingt je om je complete contactenlijst met Meta te synchroniseren, inclusief nummers van mensen die jou nooit toestemming hebben gegeven.
2. **Meta's 'Regulated Verticals' beleid:** Meta verbiedt in haar eigen voorwaarden het uitwisselen van medische- en gezondheidsinformatie via reguliere chats zodra lokale wetgeving (zoals de AVG) verzwaarde eisen stelt.

De enige legitieme route voor salons en klinieken is de officiële **WhatsApp Business API** via een geautoriseerde softwarepartner (zoals WATI) met hosting binnen de Europese Economische Ruimte (EER). Hierbij worden geen contactenlijsten leeggetrokken en worden gegevens niet gebruikt voor advertentieprofilering door derden.

## De EU AI Act: Transparantie en het verbod op emotieherkenning

Vanaf 2026 handhaaft Europa de **EU AI Act** met boetes die kunnen oplopen tot €35 miljoen of 7% van de wereldwijde omzet. Voor onze Voice-AI en chatbots hanteren we daarom twee ononderhandelbare principes:

* **Actieve Transparantieplicht (Artikel 50):** Onze AI doet zich nooit stiekem voor als een mens. Een telefoongesprek start altijd direct met: *"Goedendag, u spreekt met de virtuele assistent van [Salonnaam]"*. Geen trucjes, radicale eerlijkheid.
* **Het verbod op emotie-AI op de werkvloer:** Sinds februari 2025 verbiedt Artikel 5(1)(f) van de AI Act elke vorm van AI-emotieherkenning bij werknemers. Onze spraaktechnologie analyseert daarom nooit de stemverheffing of emoties van stylisten, maar schakelt uitsluitend door op basis van inhoudelijke criteria.

Privacy by Design is bij Kappersassistent geen juridische disclaimer achteraf; het zit ingebakken in de eerste regel code van onze architectuur.

---

*Vincent van Munster is sociaal ondernemer, AI-innovator en oprichter van WeAreImpact en Kappersassistent. Als voormalig welzijnsdirecteur én vader van twee kinderen bouwt hij aan AI-oplossingen met één doel: kille technologie inzetten om warme handen en kostbare tijd vrij te spelen.*

Beperkt beschikbaar voor strategische sparring en AI-implementatie (max. 2–3 dagen per week) via WeAreImpact.nl en Kappersassistent.nl.