---
title: "No-shows aanpakken: wat een kantonrechter in Middelburg ons leert over lege stoelen"
slug: "no-show-beleid-kappers-middelburg-uitspraak"
category: "kennisbank"
focus_keyphrase: "juridisch no show beleid kapper"
meta_description: "Waarom een bordje bij de balie waardeloos is bij no-shows. Ontdek hoe de Middelburg-uitspraak jouw salon beschermt en no-shows onder de 2% brengt."
author: "Vincent van Munster"
date: "2026-09-09"
---

# No-shows aanpakken: wat een kantonrechter in Middelburg ons leert over lege stoelen

Wanneer mensen horen dat ik als voormalig welzijnsdirecteur urenlang kan praten over algemene voorwaarden en checkbox-architectuur voor kappers, kijken sommigen even verrast op. Want: Vincent en juridische procesvoering in de salon? 

Mijn antwoord aan de keukentafel is altijd hetzelfde: juist omdát ik om mensen geef, kan ik slecht tegen onrecht op de werkvloer. In 2014 stapte ik bewust uit de corporate ratrace om fulltime vader te zijn. Tijd is het allerduurste bezit dat we hebben. In een salon is tijd letterlijk het product dat je verkoopt. Een pot stylingwax die vandaag niet verkoopt, staat er morgen nog. Maar een leeg uur door een klant die zonder afzegging wegblijft voor een balayage van €180, is een uur dat je nooit meer inhaalt. Verdampt. 

Voor een gemiddelde salon met vier stoelen loopt de directe schade door no-shows al snel op tot circa €12.000 per jaar. Toch zie ik dagelijks saloneigenaren met lege handen staan omdat hun annuleringsbeleid juridisch zo lek is als een mandje.

## Het failliet van het bordje bij de kassa: de Middelburg-uitspraak

Veel ondernemers wanen zich veilig met een geprint A4’tje op de balie: *“Afspraken dienen 24 uur van tevoren te worden geannuleerd, anders brengen wij 50% in rekening.”*

Ik moet je uit de droom helpen: juridisch gezien heeft dat bordje nul komma nul waarde. De kantonrechter in Middelburg wees in een richtinggevende uitspraak een vordering van een salon tegen een wegblijvende klant keihard af. Waarom? De consument geniet in Nederland zware wettelijke bescherming. De rechter oordeelde dat de salon niet proactief kon bewijzen dat de klant op het moment van de afspraakbevestiging kennis had genomen van de voorwaarden én deze expliciet had geaccepteerd.

Passieve communicatie — regels vermelden op Instagram, onderaan een nieuwsbrief of op een bordje in de salon — is voor een incasso of betwisting waardeloos. De wet eist **expliciete acceptatie** vóórdat de overeenkomst tot stand komt.

## De juridische checklist voor een waterdichte boekingsstraat

Om no-show kosten en aanbetalingen rechtsgeldig te kunnen handhaven, moet je digitale boekingsproces voldoen aan drie harde criteria:

* **Directe inzichtelijkheid:** De algemene voorwaarden en het annuleringsprotocol moeten vóór de afronding van de boeking met één klik bereikbaar zijn via een duidelijke hyperlink.
* **Begrijpelijkheid:** Geen mistige juridische termen, maar glasheldere taal. Vermeld exact de termijn (bijv. tot 24 of 48 uur kosteloos verplaatsen) en het concrete bedrag of percentage dat daarna verschuldigd is.
* **De verplichte actieve checkbox:** De klant moet zélf een vinkje zetten bij: *“Ik ga akkoord met de algemene voorwaarden en het annuleringsbeleid.”* Een voorgevinkt vakje is wettelijk nietig.

```
[ ] Ik ga akkoord met de algemene voorwaarden en begrijp dat bij annulering binnen 24 uur 50% van het behandeltarief in rekening kan worden gebracht.
```

## Van 8% naar onder de 2% no-shows: de gouden workflow

Een juridisch sluitend beleid is geen strafmiddel; het is een instrument voor wederzijds respect. In de praktijk combineren we bij Kappersassistent de juridische kaders met slimme automatisering:

1. **Gedifferentieerde aanbetalingen:** Laat nieuwe klanten of klanten die een lange verfsessie boeken (>€60) via Stripe of Mollie direct 20% tot 50% aanbetalen. Dit werpt direct een psychologische drempel op tegen gemakzuchtig wegblijven.
2. **De SMS-bevestigingsflow (98% open rate):** Stuur direct na het boeken een bevestiging met een agenda-bestand (.ics) en 24 uur vooraf een geautomatiseerde SMS-herinnering. Alleen deze SMS-stap reduceert het aantal no-shows al met 29% tot 70%.
3. **De menselijke maat (Three-Strikes-beleid):** Een trouwe klant die door autopech een afspraak mist, stuur je geen incasso. Geef vaste klanten twee keer het voordeel van de twijfel; blokkeer pas bij stelselmatige recidive de mogelijkheid om online te reserveren.

Als je het fundament op orde hebt, daalt je uitval van 8% naar minder dan 2%. Dat scheelt niet alleen duizenden euro's; het brengt de rust terug in je team.

---

*Vincent van Munster is sociaal ondernemer, AI-innovator en oprichter van WeAreImpact en Kappersassistent. Als voormalig welzijnsdirecteur én vader van twee kinderen bouwt hij aan AI-oplossingen met één doel: kille technologie inzetten om warme handen en kostbare tijd vrij te spelen.*

Zullen we eens koffie drinken? Als ondernemer en vader hoor ik graag waar jouw salonpraktijk vandaag de dag écht vastloopt.